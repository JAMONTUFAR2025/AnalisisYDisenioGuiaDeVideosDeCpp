// Josue Alejandro Montufar Zuniga
// 202510050077
/* La sentencia while:

	while(expresion logica)
	{
		conjunto de instrucciones;
	}
*/

#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
	int i;
	
	i = 10;
	
	while(i >= 1)
	{
		cout<<i<<endl;
		i--;
	}
	
	getch();
	return 0;
}