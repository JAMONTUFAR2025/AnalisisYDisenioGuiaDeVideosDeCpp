// Josue Alejandro Montufar Zuniga
// 202510050077
/* La sentencia for

	for(expr1; epresion logica; expr2)
	{
		conjunto de instrucciones;
	}
*/

#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
	for(int i = 10; i >= 1; i--)
	{
		cout<<i<<endl;
	}
	
	getch();
	return 0;
}