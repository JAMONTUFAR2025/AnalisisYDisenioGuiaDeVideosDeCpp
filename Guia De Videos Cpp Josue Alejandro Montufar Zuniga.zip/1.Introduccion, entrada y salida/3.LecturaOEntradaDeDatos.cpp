// Josue Alejandro Montufar Zuniga
// 202510050077
// Lectura o entrada de datos

#include<iostream>

using namespace std;

int main()
{
	float numero; // Definiendo la variable
	
	cout<<"Digite un numero: ";
	cin>>numero; // Guardando la variable
	
	cout<<"\nEl numero que digito es: "<<numero;
	
	
	return 0;
}