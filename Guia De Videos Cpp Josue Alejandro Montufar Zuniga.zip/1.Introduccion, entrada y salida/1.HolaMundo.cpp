// Josue Alejandro Montufar Zuniga
// 202510050077
// Primer programa en C++

#include<iostream>

using namespace std;

int main()
{
	
	cout<<"Hola mundo :D"<<endl;
	
	return 0;
}