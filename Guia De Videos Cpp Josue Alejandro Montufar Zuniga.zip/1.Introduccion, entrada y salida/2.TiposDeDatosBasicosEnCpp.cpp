// Josue Alejandro Montufar Zuniga
// 202510050077
// Tipos de datos basicos de C++

#include<iostream>

using namespace std;

int main()
{
	int entero = 15;
	float flotante = 10.45;
	double mayor = 16.3456;
	char letra = 'a';
	
	cout<<letra;
	
	return 0;
}